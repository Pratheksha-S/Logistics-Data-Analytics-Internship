"""
Week 4 - Evaluation and Validation
Loads the saved best model, runs 5-fold cross-validation to check the
RMSE result is stable (not a lucky train/test split), performs a small
GridSearchCV hyperparameter search around the Random Forest's key
parameters, and produces the diagnostic plots used in the report:
actual-vs-predicted, residuals, and feature importance.
"""

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GridSearchCV, KFold, cross_val_score
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

sns.set_theme(style="whitegrid")

X_train = pd.read_csv("data/X_train.csv")
X_test = pd.read_csv("data/X_test.csv")
y_train = pd.read_csv("data/y_train.csv").squeeze()
y_test = pd.read_csv("data/y_test.csv").squeeze()

CATEGORICAL = ["mode_of_transport", "destination_region", "origin_warehouse"]

best_pipe = joblib.load("models/best_model.joblib")  # winner from 02_model_training.py

# --- 5-fold cross-validation on the training-set winner (sanity check on stability) ---
cv = KFold(n_splits=5, shuffle=True, random_state=42)
cv_rmse = -cross_val_score(best_pipe, X_train, y_train, cv=cv, scoring="neg_root_mean_squared_error")
print("=== 5-FOLD CROSS-VALIDATION - baseline winner (RMSE) ===")
print(f"Fold scores: {np.round(cv_rmse, 3)}")
print(f"Mean RMSE: {cv_rmse.mean():.3f}  Std: {cv_rmse.std():.3f}")

# --- Hyperparameter tuning on the ensemble method (Random Forest), regardless of
#     which model won the initial comparison, since ensemble tuning is a required
#     step for this task and tells us whether tuning can close any performance gap ---
rf_preprocessor = ColumnTransformer(
    transformers=[("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL)],
    remainder="passthrough",
)
rf_pipe = Pipeline([("prep", rf_preprocessor), ("model", RandomForestRegressor(random_state=42))])

param_grid = {
    "model__n_estimators": [150, 300],
    "model__max_depth": [6, 10, None],
    "model__min_samples_leaf": [1, 3],
}
grid = GridSearchCV(rf_pipe, param_grid, cv=3, scoring="neg_root_mean_squared_error", n_jobs=-1)
grid.fit(X_train, y_train)
print("\n=== GRID SEARCH BEST PARAMS (Random Forest) ===")
print(grid.best_params_)
print(f"Best CV RMSE (tuned Random Forest): {-grid.best_score_:.3f}")

tuned_rf = grid.best_estimator_
rf_preds = tuned_rf.predict(X_test)
rf_rmse = mean_squared_error(y_test, rf_preds) ** 0.5

# --- Pick whichever model is genuinely best on the held-out test set ---
baseline_preds = best_pipe.predict(X_test)
baseline_rmse = mean_squared_error(y_test, baseline_preds) ** 0.5

if rf_rmse < baseline_rmse:
    tuned_model = tuned_rf
    final_name = "Tuned Random Forest"
else:
    tuned_model = best_pipe
    final_name = "Linear Regression (baseline winner; tuning the ensemble did not beat it)"

joblib.dump(tuned_model, "models/best_model_tuned.joblib")

# --- Final test-set evaluation with the selected final model ---
preds = tuned_model.predict(X_test)
rmse = mean_squared_error(y_test, preds) ** 0.5
mae = mean_absolute_error(y_test, preds)
r2 = r2_score(y_test, preds)
print(f"\n=== FINAL MODEL SELECTED: {final_name} ===")
print(f"RMSE: {rmse:.3f} days | MAE: {mae:.3f} days | R2: {r2:.3f}")

# --- Plot 1: Actual vs Predicted ---
plt.figure(figsize=(6.5, 6))
plt.scatter(y_test, preds, alpha=0.4, color="#2c6e8f", s=25)
lims = [0, max(y_test.max(), preds.max()) + 1]
plt.plot(lims, lims, "--", color="#c1440e", linewidth=1.5, label="Perfect prediction")
plt.xlabel("Actual Delivery Time (days)")
plt.ylabel("Predicted Delivery Time (days)")
plt.title("Actual vs. Predicted Delivery Time")
plt.legend()
plt.tight_layout()
plt.savefig("images/01_actual_vs_predicted.png", dpi=150)
plt.close()

# --- Plot 2: Residuals ---
residuals = y_test.values - preds
plt.figure(figsize=(8, 5))
sns.histplot(residuals, bins=30, kde=True, color="#2c6e8f")
plt.axvline(0, color="#c1440e", linestyle="--")
plt.xlabel("Residual (Actual - Predicted, days)")
plt.ylabel("Number of Shipments")
plt.title("Distribution of Prediction Errors")
plt.tight_layout()
plt.savefig("images/02_residuals.png", dpi=150)
plt.close()

# --- Plot 3: Feature importance (tree-based) or standardized coefficients (linear) ---
ohe = tuned_model.named_steps["prep"].named_transformers_["cat"]
cat_names = list(ohe.get_feature_names_out(["mode_of_transport", "destination_region", "origin_warehouse"]))
num_names = ["distance_km", "shipment_volume_units", "promised_time_days", "ship_month_num"]
all_names = cat_names + num_names
final_estimator = tuned_model.named_steps["model"]

if hasattr(final_estimator, "feature_importances_"):
    scores = final_estimator.feature_importances_
    score_label, chart_title = "importance", "Top Feature Importances - Delivery Time Model"
else:
    scores = np.abs(final_estimator.coef_)  # magnitude of linear coefficients
    score_label, chart_title = "importance", "Top Feature Coefficients (abs.) - Delivery Time Model"

imp_df = pd.DataFrame({"feature": all_names, "importance": scores}).sort_values(
    "importance", ascending=False
).head(12)

plt.figure(figsize=(8, 6))
sns.barplot(data=imp_df, x="importance", y="feature", hue="feature", palette="crest", legend=False)
plt.title(chart_title)
plt.xlabel("Relative importance")
plt.ylabel("")
plt.tight_layout()
plt.savefig("images/03_feature_importance.png", dpi=150)
plt.close()

print("\nEvaluation plots saved to images/.")
