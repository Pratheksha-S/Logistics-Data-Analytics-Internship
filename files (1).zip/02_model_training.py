"""
Week 4 - Model Selection and Training
Trains three candidate models on the delivery-time forecasting problem:
  1. Linear Regression       - simple, interpretable baseline
  2. Decision Tree Regressor - captures non-linear mode/distance interactions
  3. Random Forest Regressor - ensemble method, usually the strongest of the three
All three share the same preprocessing pipeline (one-hot encoding for the
categorical fields, passthrough for numeric fields) so that the comparison
is fair. The best-performing model is persisted with joblib for later use
in evaluation and optimization.
"""

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.tree import DecisionTreeRegressor

X_train = pd.read_csv("data/X_train.csv")
X_test = pd.read_csv("data/X_test.csv")
y_train = pd.read_csv("data/y_train.csv").squeeze()
y_test = pd.read_csv("data/y_test.csv").squeeze()

CATEGORICAL = ["mode_of_transport", "destination_region", "origin_warehouse"]
NUMERIC = ["distance_km", "shipment_volume_units", "promised_time_days", "ship_month_num"]

preprocessor = ColumnTransformer(
    transformers=[("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL)],
    remainder="passthrough",
)

candidates = {
    "Linear Regression": LinearRegression(),
    "Decision Tree": DecisionTreeRegressor(max_depth=6, random_state=42),
    "Random Forest": RandomForestRegressor(n_estimators=300, max_depth=10, random_state=42),
}

results = []
fitted_pipelines = {}

for name, model in candidates.items():
    pipe = Pipeline([("prep", preprocessor), ("model", model)])
    pipe.fit(X_train, y_train)
    preds = pipe.predict(X_test)

    rmse = mean_squared_error(y_test, preds) ** 0.5
    mae = mean_absolute_error(y_test, preds)
    r2 = r2_score(y_test, preds)

    results.append({"model": name, "RMSE": round(rmse, 3), "MAE": round(mae, 3), "R2": round(r2, 3)})
    fitted_pipelines[name] = pipe

results_df = pd.DataFrame(results).sort_values("RMSE")
print("=== MODEL COMPARISON (test set) ===")
print(results_df.to_string(index=False))

best_name = results_df.iloc[0]["model"]
best_pipeline = fitted_pipelines[best_name]
joblib.dump(best_pipeline, "models/best_model.joblib")
results_df.to_csv("data/model_comparison.csv", index=False)

print(f"\nBest model: {best_name} -> saved to models/best_model.joblib")
