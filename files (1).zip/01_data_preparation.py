"""
Week 4 - Data Preparation
Problem: forecast delivery_time_days (a continuous logistics KPI) using
only information that is known at shipment-booking time - i.e. before the
shipment has actually moved. Fields that are only known AFTER delivery
(transportation_cost_inr's noise component, delay_days, on_time_delivery,
customer_rating, cost_per_km) are deliberately excluded to avoid data
leakage; a real dispatcher would not have these at prediction time.

Reuses the Week 3 logistics_dataset.csv (1,200 shipments) so that the
predictive model is grounded in the same operational data already
explored in Week 3.
"""

import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("logistics_dataset.csv", parse_dates=["ship_date"])

# Features known at booking time
FEATURES = [
    "distance_km",
    "shipment_volume_units",
    "mode_of_transport",
    "destination_region",
    "origin_warehouse",
    "promised_time_days",
]
TARGET = "delivery_time_days"

df["ship_month_num"] = pd.to_datetime(df["ship_date"]).dt.month
FEATURES.append("ship_month_num")

X = df[FEATURES]
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

X_train.to_csv("data/X_train.csv", index=False)
X_test.to_csv("data/X_test.csv", index=False)
y_train.to_csv("data/y_train.csv", index=False)
y_test.to_csv("data/y_test.csv", index=False)

print("Problem: forecast delivery_time_days (regression)")
print(f"Features used: {FEATURES}")
print(f"Train shape: {X_train.shape}  Test shape: {X_test.shape}")
print(f"Target mean (train): {y_train.mean():.2f} days | std: {y_train.std():.2f} days")
