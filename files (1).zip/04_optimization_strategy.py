"""
Week 4 - Optimization Strategy
Uses the tuned predictive model to run a "what-if" simulation rather than
just reporting historical averages. For every shipment currently sent by
Road, the model re-predicts delivery time under a counterfactual Rail
assignment (all other features held constant). This identifies which
Road shipments would likely become on-time if reassigned to Rail -
directly turning model output into a resource-allocation recommendation,
plus a proactive flag for shipments at high risk of missing their
promised delivery window under their current, actual mode.
"""

import joblib
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

sns.set_theme(style="whitegrid")

model = joblib.load("models/best_model_tuned.joblib")

df = pd.read_csv("logistics_dataset.csv", parse_dates=["ship_date"])
df["ship_month_num"] = pd.to_datetime(df["ship_date"]).dt.month

FEATURES = [
    "distance_km", "shipment_volume_units", "mode_of_transport",
    "destination_region", "origin_warehouse", "promised_time_days",
    "ship_month_num",
]

# --- 1. Proactive delay-risk flagging (current, actual mode) ---
df["predicted_delivery_days"] = model.predict(df[FEATURES])
df["predicted_delay_risk"] = df["predicted_delivery_days"] - df["promised_time_days"]
high_risk = df[df["predicted_delay_risk"] > 1.0]
print(f"Shipments flagged as high delay-risk (predicted > promised + 1 day): "
      f"{len(high_risk)} of {len(df)} ({len(high_risk)/len(df)*100:.1f}%)")
print(high_risk["mode_of_transport"].value_counts())

# --- 2. Counterfactual simulation: Road -> Rail reassignment ---
road = df[df["mode_of_transport"] == "Road"].copy()
road_as_rail = road.copy()
road_as_rail["mode_of_transport"] = "Rail"

road["predicted_current"] = model.predict(road[FEATURES])
road["predicted_if_rail"] = model.predict(road_as_rail[FEATURES])

road["on_time_current_pred"] = road["predicted_current"] <= road["promised_time_days"] + 0.5
road["on_time_if_rail_pred"] = road["predicted_if_rail"] <= road["promised_time_days"] + 0.5

current_rate = road["on_time_current_pred"].mean() * 100
rail_rate = road["on_time_if_rail_pred"].mean() * 100
improved = road[(~road["on_time_current_pred"]) & (road["on_time_if_rail_pred"])]

print(f"\nRoad shipments: predicted on-time rate as Road = {current_rate:.1f}%")
print(f"Same shipments, predicted on-time rate if reassigned to Rail = {rail_rate:.1f}%")
print(f"Shipments that would flip from late to on-time under Rail: {len(improved)} "
      f"({len(improved)/len(road)*100:.1f}% of all Road shipments)")

# --- Chart: predicted on-time rate, Road (actual) vs Rail (counterfactual) ---
plt.figure(figsize=(6.5, 5))
labels = ["Road (current)", "Rail (simulated)"]
values = [current_rate, rail_rate]
sns.barplot(x=labels, y=values, hue=labels, palette=["#c1440e", "#2c6e8f"], legend=False)
plt.ylim(0, 105)
plt.ylabel("Predicted On-Time Rate (%)")
plt.title("Simulated Impact of Reassigning Road Shipments to Rail")
for i, v in enumerate([current_rate, rail_rate]):
    plt.text(i, v + 1.5, f"{v:.1f}%", ha="center")
plt.tight_layout()
plt.savefig("images/04_mode_reassignment_simulation.png", dpi=150)
plt.close()

# --- Chart: distance threshold where Rail catches up to Road ---
plt.figure(figsize=(8, 5))
plt.scatter(road["distance_km"], road["predicted_current"], alpha=0.35, s=18,
            color="#c1440e", label="Predicted - stays Road")
plt.scatter(road["distance_km"], road["predicted_if_rail"], alpha=0.35, s=18,
            color="#2c6e8f", label="Predicted - switched to Rail")
plt.xlabel("Distance (km)")
plt.ylabel("Predicted Delivery Time (days)")
plt.title("Predicted Delivery Time by Distance: Road vs. Simulated Rail")
plt.legend()
plt.tight_layout()
plt.savefig("images/05_distance_threshold_simulation.png", dpi=150)
plt.close()

df.to_csv("data/predictions_with_risk_flags.csv", index=False)
print("\nOptimization simulation charts saved to images/.")
